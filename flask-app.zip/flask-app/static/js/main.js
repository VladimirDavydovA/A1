var app = new Vue({
    el: '#app',
    data: {
        connected: false,
        ros: null,
        ws_address: 'ws://localhost:9090',
        logs: [],
        loading: false,
        topic: null // Убедитесь, что поле для топика существует
    },
    methods: {
        connect: function() {
            this.loading = true;
            this.logs = ['Connecting to rosbridge server...', ...this.logs];
            if (this.ros) {
                this.logs = ['Already connected or in the process of connecting.', ...this.logs];
                this.loading = false;
                return;
            }
            this.ros = new ROSLIB.Ros({
                url: this.ws_address
            });

            this.ros.on('connection', () => {
                this.connected = true;
                this.loading = false;
                this.logs = ['Connected!', ...this.logs];
            });

            this.ros.on('error', (error) => {
                this.loading = false;
                this.logs = [`Error connecting to websocket server: ${error}`, ...this.logs];
                console.error('Connection error: ', error);
            });

            this.ros.on('close', () => {
                this.connected = false;
                this.ros = null;
                this.loading = false;
                this.logs = ['Connection to websocket server closed.', ...this.logs];
            });
        },

        disconnect: function() {
            if (this.ros) {
                this.logs = ['Disconnecting...', ...this.logs];
                this.ros.close();
            } else {
                this.logs = ['Not connected.', ...this.logs];
            }
        },

        setTopic: function() {
            if (!this.topic) {
                this.topic = new ROSLIB.Topic({
                    ros: this.ros,
                    name: '/cmd_vel',
                    messageType: 'geometry_msgs/Twist'
                });
                this.logs = ['Topic /cmd_vel set.', ...this.logs];
            }
        },

        logMessage: function(linear, angular) {
            const logEntry = `Message sent: linear=(${linear.x}, ${linear.y}, ${linear.z}), angular=(${angular.x}, ${angular.y}, ${angular.z})`;
            this.logs = [logEntry, ...this.logs];
            console.log(logEntry); // Для отладки
        },

        forward: function() {
            this.logs = ['Forward button pressed.', ...this.logs];
            this.setTopic();
            if (!this.topic) {
                this.logs = ['Topic is not set. Cannot send message.', ...this.logs];
                return;
            }

            const message = new ROSLIB.Message({
                linear: { x: 1, y: 0, z: 0 },
                angular: { x: 0, y: 0, z: 0 }
            });
            this.topic.publish(message);
            this.logMessage(message.linear, message.angular);
        },

        stop: function() {
            this.logs = ['Stop button pressed.', ...this.logs];
            this.setTopic();
            const message = new ROSLIB.Message({
                linear: { x: 0, y: 0, z: 0 },
                angular: { x: 0, y: 0, z: 0 }
            });
            this.topic.publish(message);
            this.logMessage(message.linear, message.angular);
            this.logs = ['Some log message', ...this.logs];
            console.log(this.logs);
        },

        backward: function() {
            this.logs = ['Backward button pressed.', ...this.logs];
            this.setTopic();
            const message = new ROSLIB.Message({
                linear: { x: -1, y: 0, z: 0 },
                angular: { x: 0, y: 0, z: 0 }
            });
            this.topic.publish(message);
            this.logMessage(message.linear, message.angular);
        },

        turnLeft: function() {
            this.logs = ['Turn Left button pressed.', ...this.logs];
            this.setTopic();
            const message = new ROSLIB.Message({
                linear: { x: 0.5, y: 0, z: 0 },
                angular: { x: 0, y: 0, z: 0.5 }
            });
            this.topic.publish(message);
            this.logMessage(message.linear, message.angular);
        },

        turnRight: function() {
            this.logs = ['Turn Right button pressed.', ...this.logs];
            this.setTopic();
            const message = new ROSLIB.Message({
                linear: { x: 0.5, y: 0, z: 0 },
                angular: { x: 0, y: 0, z: -0.5 }
            });
            this.topic.publish(message);
            this.logMessage(message.linear, message.angular);
        },
    }
});

