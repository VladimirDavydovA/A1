#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist

# Функция-обработчик для обработки входящих сообщений
def callback(msg):
    # Обработка линейных координат
    linear = msg.linear
    angular = msg.angular
    rospy.loginfo(f"Received message: linear=({linear.x}, {linear.y}, {linear.z}), angular=({angular.x}, {angular.y}, {angular.z})")

    # Выполняем действия в зависимости от направления
    if linear.x > 0:
        rospy.loginfo("Moving forward")
    elif linear.x < 0:
        rospy.loginfo("Moving backward")
    elif angular.z > 0:
        rospy.loginfo("Turning left")
    elif angular.z < 0:
        rospy.loginfo("Turning right")
    else:
        rospy.loginfo("Stopping")

def listener():
    # Инициализация ROS-ноды
    rospy.init_node('cmd_vel_listener', anonymous=True)
    # Подписка на топик
    rospy.Subscriber('/cmd_vel', Twist, callback)
    # Ожидание сообщений
    rospy.spin()

if __name__ == '__main__':
    try:
        listener()
    except rospy.ROSInterruptException:
        pass
